# Kyrgyz AI — облачная сборка APK

Проект подготовлен как Capacitor Android-приложение.

## Вариант с облачной сборкой

1. Загрузить этот ZIP в облачную среду, поддерживающую Node.js + Android SDK.
2. Выполнить:
   npm install
   npx cap add android
   npm run android:sync
3. В каталоге `android/` собрать:
   ./gradlew assembleDebug
4. APK будет:
   `android/app/build/outputs/apk/debug/app-debug.apk`

Для публикации в Google Play позже использовать:
`./gradlew bundleRelease`

Важно: Firebase/SMS в тестовой APK можно оставить отключёнными. Для production-версии сначала подключить реальные Firebase credentials.
