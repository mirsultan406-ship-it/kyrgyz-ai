# v2.10 — Облачные заявки

В `src/services/requests.ts` находится готовый Firestore слой для заявок.

## Поток
1. Авторизованный клиент создаёт документ `requests/{requestId}`.
2. Мастер подписывается на свои заявки через `watchProviderRequests`.
3. Клиент подписывается на свои заявки через `watchClientRequests`.
4. Мастер меняет статус: `Принята`, `Отклонена`, `Завершена`.
5. Клиент получает изменение в реальном времени через Firestore listener.

## Перед production
- подключить Firebase credentials в `.env`;
- заменить локальный `createServiceRequest()` на `createCloudRequest()`;
- при входе передавать Firebase `uid` клиента;
- в кабинете мастера использовать `watchProviderRequests(providerUid, ...)`;
- в профиле клиента использовать `watchClientRequests(userUid, ...)`;
- настроить Firestore indexes, если Firebase Console попросит индекс для `where + orderBy`;
- проверить Security Rules на тестовых аккаунтах.

Текущий ZIP сохраняет локальный прототип и содержит готовый cloud-service слой отдельно, чтобы не создавать ложного ощущения, что SMS/Firebase уже активированы без credentials.
