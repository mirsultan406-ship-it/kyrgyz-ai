# Подключение Firebase к Kyrgyz AI

## 1. Создайте проект
В Firebase Console создайте проект и добавьте Web App.

## 2. Включите Authentication
Authentication → Sign-in method → Phone.

Для разработки добавьте тестовые номера Firebase. Для реальных SMS настройте проект и разрешённые домены.

## 3. Создайте Firestore
Создайте базу Firestore в production mode.

## 4. Заполните `.env`
Скопируйте `.env.example` в `.env` и вставьте значения Web App из Firebase.

## 5. Установите зависимости
`npm install`

## 6. Запустите
`npm run dev`

После этого Firebase-ready слой находится в `src/services/firebase.ts`, а синхронизация профиля — в `src/services/cloudSync.ts`.

### Важно
Не публикуйте секреты и сервисные ключи в клиентском коде. Web Firebase config сам по себе не является секретом, но доступ к данным должен ограничиваться Firestore Security Rules.
