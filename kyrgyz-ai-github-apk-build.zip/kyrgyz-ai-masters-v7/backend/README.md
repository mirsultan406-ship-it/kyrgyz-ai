# Kyrgyz AI backend — v2.6 blueprint

This folder defines the production architecture for authentication and cloud sync.

## Recommended stack
- Firebase Authentication (phone/SMS OTP)
- Cloud Firestore for profiles, favorites, history and requests
- Firebase App Check for abuse protection
- Cloud Functions for trusted server-side operations

## Collections
- `users/{uid}` — name, phone, language, createdAt
- `users/{uid}/favorites/{placeId}`
- `users/{uid}/history/{placeId}`
- `users/{uid}/requests/{requestId}`
- `providers/{providerId}` — service provider profile
- `places/{placeId}` — normalized organization data

## Security
Clients must only read/write their own `users/{uid}/...` subcollections. Provider and admin data must use role-based rules and server-side validation.

## SMS flow
1. User enters phone number.
2. Firebase sends OTP.
3. User enters the code.
4. Firebase returns a verified `uid`.
5. App syncs profile/favorites/history/requests with Firestore.

The current app remains a frontend prototype until Firebase project credentials are supplied and the app is connected to a real project.
