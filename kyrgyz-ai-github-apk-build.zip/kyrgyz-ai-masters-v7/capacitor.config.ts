import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'kg.kyrgyzai.app',
  appName: 'Kyrgyz AI',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
