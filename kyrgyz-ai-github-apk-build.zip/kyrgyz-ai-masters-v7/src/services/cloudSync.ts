import { doc, getDoc, setDoc, collection, getDocs } from "firebase/firestore";
import { db } from "./firebase";

export async function saveProfile(uid: string, profile: Record<string, unknown>) {
  if (!db) throw new Error("Firebase is not configured");
  await setDoc(doc(db, "users", uid), profile, { merge: true });
}

export async function loadProfile(uid: string) {
  if (!db) return null;
  const snap = await getDoc(doc(db, "users", uid));
  return snap.exists() ? snap.data() : null;
}

export async function loadFavorites(uid: string) {
  if (!db) return [];
  const snap = await getDocs(collection(db, "users", uid, "favorites"));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}
