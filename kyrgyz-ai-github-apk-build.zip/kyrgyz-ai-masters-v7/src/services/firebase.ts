import { initializeApp, getApps } from "firebase/app";
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const config = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

export const firebaseConfigured = Object.values(config).every(Boolean);

export const firebaseApp = firebaseConfigured
  ? (getApps()[0] ?? initializeApp(config))
  : null;

export const auth = firebaseApp ? getAuth(firebaseApp) : null;
export const db = firebaseApp ? getFirestore(firebaseApp) : null;

export const setupRecaptcha = (containerId: string) => {
  if (!auth) throw new Error("Firebase is not configured");
  return new RecaptchaVerifier(auth, containerId, { size: "invisible" });
};

export const sendPhoneOtp = async (phone: string, verifier: RecaptchaVerifier) => {
  if (!auth) throw new Error("Firebase is not configured");
  return signInWithPhoneNumber(auth, phone, verifier);
};
