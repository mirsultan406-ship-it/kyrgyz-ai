import {
  addDoc, collection, doc, onSnapshot, orderBy, query,
  serverTimestamp, updateDoc, where
} from "firebase/firestore";
import { db } from "./firebase";

export type ServiceRequest = {
  id?: string;
  masterId: string;
  masterName: string;
  service: string;
  city?: string;
  clientUid?: string;
  clientName?: string;
  phone?: string;
  text?: string;
  status: "Новая" | "Принята" | "Отклонена" | "Завершена";
  createdAt?: unknown;
};

export async function createCloudRequest(request: ServiceRequest) {
  if (!db) throw new Error("Firebase is not configured");
  const ref = await addDoc(collection(db, "requests"), {
    ...request,
    createdAt: serverTimestamp(),
  });
  return ref.id;
}

export async function updateCloudRequest(id: string, status: ServiceRequest["status"]) {
  if (!db) throw new Error("Firebase is not configured");
  await updateDoc(doc(db, "requests", id), { status });
}

export function watchClientRequests(uid: string, cb: (rows: ServiceRequest[]) => void) {
  if (!db) return () => {};
  const q = query(
    collection(db, "requests"),
    where("clientUid", "==", uid),
    orderBy("createdAt", "desc")
  );
  return onSnapshot(q, snap =>
    cb(snap.docs.map(d => ({ id: d.id, ...(d.data() as ServiceRequest) })))
  );
}

export function watchProviderRequests(masterId: string, cb: (rows: ServiceRequest[]) => void) {
  if (!db) return () => {};
  const q = query(
    collection(db, "requests"),
    where("masterId", "==", masterId),
    orderBy("createdAt", "desc")
  );
  return onSnapshot(q, snap =>
    cb(snap.docs.map(d => ({ id: d.id, ...(d.data() as ServiceRequest) })))
  );
}
